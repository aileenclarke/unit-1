//initialize function called when the script loads
function initialize(){
	cities();
	debugAjax();
};


// create a single array of objects for cities and population
function cities(){
		var cityPop = [
			{ 
				city: 'Madison',
				population: 233209
			},
			{
				city: 'Milwaukee',
				population: 594833
			},
			{
				city: 'Green Bay',
				population: 104057
			},
			{
				city: 'Superior',
				population: 27244
			}
		];
		
		//create a table element
		var table = document.createElement("table");

		//create a header row element and append it to the table
		var headerRow = document.createElement("tr");
		table.appendChild(headerRow);

		//create the "City" and "Population" column headers
		headerRow.insertAdjacentHTML("beforeend","<th>City</th><th>Population</th>")
	
		//loop to add a new row for each city
		cityPop.forEach(function(cityObject){
			//assign longer html strings to a variable
			var rowHtml = "<tr><td>" + cityObject.city + "</td><td>" + cityObject.population + "</td></tr>";
			//add the row's html string to the table
			table.insertAdjacentHTML('beforeend',rowHtml);
		});
		
		//append the table element to the div
		document.querySelector("#mydiv").appendChild(table);

	addColumns(cityPop); //call the addColumns function with the argument cityPop
	addEvents(); //call the function addEvents
	
};

// create a function named addColumns
function addColumns(cityPop){
    
	// returns all objects that meet the selection criteria "tr". For each object, run the local function with arguments row and i
    document.querySelectorAll("tr").forEach(function(row, i){

		// if else statement adds column header City Size for i = 0
		if (i == 0){
    		row.insertAdjacentHTML('beforeend', '<th>City Size</th>');
			
		} else {

			// create variable named citySize and assign it a value based on its population size
			var citySize;
			
    		if (cityPop[i-1].population < 100000){
    			citySize = 'Small';
				
    		} else if (cityPop[i-1].population < 500000){
    			citySize = 'Medium';
				

    		} else {
    			citySize = 'Large';
				
    		};
			
			// insert the value of citySize into the html at the position 'beforeend'
			row.insertAdjacentHTML('beforeend',citySize);      

    	};
    });
};

// create function named addEvents
function addEvents(){
	
	// returns all objects that meet the selection criteria "table" and add a mouseover listener with anonymous handler function
	document.querySelector("table").addEventListener("mouseover", function(){
		
		// create variable color that holds string 
		var color = "rgb(";

		// for loop that will loop 3 times
		for (var i=0; i<3; i++){

			// create variable random and assign numeric value
			var random = Math.round(Math.random() * 255);
			
			// update value of color by concatenating value of random
			color += random;
			
			// update value of color by concatenation
			if (i<2){
				color += ",";
			
			} else {
				color += ")";
			};
		};
		
		// returns all objects that mee the selection criteria "table" and apply the color style with the value of "color" determined above
		document.querySelector("table").style.color = color;     
		
	});

	// create function clickme that will return alert
	function clickme(){

		alert('Hey, you clicked me!');
	};
	
	// returns all objects that meet the selection criteria "table" and add a click listener with the function click me
	document.querySelector("table").addEventListener("click", clickme)
};

// execute the script as soon as the DOM is prepared
document.addEventListener('DOMContentLoaded',initialize)

// Activity 4
/*
function jsAjax(){
    // Step 1: Create the data request 
    var request = new Request('data/MegaCities.geojson');
    //Step 2: define Fetch parameters 
    var init = {
        method: 'GET'
    }
    //Step 3: use Fetch to retrieve data
    fetch(request, init)
        .then(conversion) //Step 4 convert data to usable form
        .then(callback) //Step 5 Send retrieved data to a callback function
};

//define conversion callback function
function conversion(response){
	//convert data to usable form
	return response.json();
}
  
  //define callback function
function callback(response){
	//tasks using the data go here
	console.log(JSON.stringify(response));
}
window.onload = jsAjax();
*/

// Activity 4: Simplifying Fetch Requests
/*
//Example 2.7 line 1
function jsAjax(){
    //use Fetch to retrieve data
    fetch('data/MegaCities.geojson')
        .then(function(response){
            return response.json();
        }) 
        .then(callback) 
};

//define callback function
function callback(response){
    //tasks using the data go here
    console.log(JSON.stringify(response));
}

window.onload = jsAjax();

// Activity 4: Lesson 3
//define fetch request
function jsAjax(){
    //basic fetch
    fetch('data/MegaCities.geojson')
        .then(function(response){
            return response.json();
        }) 
        .then(callback) 
};
//define callback function
function callback(response){

    var myData = response;

    //pass data to another function
    nextFunction(myData);
};

function nextFunction(data){

    console.log(data); //contains response data held by myData in callback
};

window.onload = jsAjax();
*/

// Debug Ajax

//Example 3.5...
/*
function initialize(){
	debugAjax();
}*/

function debugCallback(response){
	document.querySelector("#mydiv").insertAdjacentHTML('beforeend', 'GeoJSON data: ' + JSON.stringify(mydata))
};

function debugAjax(){
	
	var mydata = response;
	
	fetch("data/MegaCities.geojson")
		.then(function(response){
			return response.json();
		})
		.then(function(response){
			debugCallback(mydata);
		})

	
};




